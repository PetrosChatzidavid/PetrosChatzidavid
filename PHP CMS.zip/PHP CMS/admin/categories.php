<?php include "includes/header.php" ?>

    <div id="wrapper">



        <!-- Navigation -->
        <?php include "includes/nav.php" ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to admin
                            <small>Author</small>
                        </h1>

                        <div class="col-md-6">

                       <?php
                      // STEP 2
                      insert_categories();
                        ?>

                       <form action="" method="post">
                          <div class="form-group">
                            <label for="cat-title">Add Category</label>
                            <input type="text" class="form-control" name="cat_title">
                          </div>
                          <div class="form-group">
                          <input class="btn btn-primary" type="submit" name="submit" value="Add Category">
                        </form>
                        
                        
                        
                            <?php
                            //STEP 5 UPDATE
                            if(isset($_GET['edit'])){
                              $cat_id = $_GET['edit'];

                              include "includes/update_category.php";

                            }
                            ?>

           
                  
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->
            <div class="col-md-6">

      

                    <table class="table table-bordered table-h">
                      <thead>
                        <tr>
                          <th>Id</th>
                          <th>Category Title</th>
                        </tr>
                      </thead>
                      <tbody>
             
                          <?php
                          // STEP 1 Creat the categories
                         $query = "SELECT * FROM category";
                         $select_category = mysqli_query($connection, $query);

                          while($row = mysqli_fetch_assoc($select_category)){
                            $cat_id = $row['cat_id'];
                            $cat_title = $row['cat_title'];

                            echo "<tr>";
                            echo "<td>{$cat_id}</td>";
                            echo "<td>{$cat_title}</td>"; 
                            echo "<td><a href='categories.php?delete={$cat_id}'>Delete</a></td>";
                            echo "<td><a href='categories.php?edit={$cat_id}'>Edit</a></td>";
                            echo "</tr>";
                          }
                            ?>


                            <?php

                          // STEP 3 Delete the categories
                          if(isset($_GET['delete'])){
                            $the_cat_id = $_GET['delete'];
                            $query = "DELETE FROM category WHERE cat_id = {$the_cat_id} ";
                            $delete_query = mysqli_query($connection,$query);
                            header("Location: categories.php");                           
                          }

                            ?>
             
                      </tbody>
                    </table>
                </div>
              </div>
            </div>
     


        <!-- /#page-wrapper -->
        <?php include "includes/footer.php" ?>
