<?php
function comfirmQuery($result){
  global $connection;

  if(!$result){
    die("QUERY FAILED ." . mysqli_error($connection));
  }
}



function insert_categories(){;
global $connection;
      if(isset($_POST['submit'])){
        

         $cat_title = $_POST['cat_title'];

        if($cat_title == "" || empty($cat_title)){
          echo "Failt system";

        } else {
          
          $query = "INSERT INTO category(cat_title)";
          $query .= "VALUE('$cat_title')";

          $create_select_query = mysqli_query($connection,$query);

          if(!$create_select_query){
            die("QUERY FAILED" . mysqli_error($connection));
          }
        }
      }
    }
    ?>
